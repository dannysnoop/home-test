import 'reflect-metadata';
import { createApp } from './app';
import { env } from './config/env';
import { AppDataSource } from './db/data-source';

(async () => {
    try {
        await AppDataSource.initialize();          // ✅ KHỞI TẠO DB TRƯỚC
        const app = createApp();
        app.listen(env.PORT, () => {
            console.log(`[server] http://localhost:${env.PORT}`);
        });
    } catch (e) {
        console.error('Failed to start:', e);
        process.exit(1);
    }
})();