import { Request, Response, NextFunction } from 'express';
import { verifyToken } from '../utils/jwt';

export function authGuard(req: Request, res: Response, next: NextFunction) {
    const header = req.headers.authorization;
    if (!header) return res.status(401).json({ error: 'Missing Authorization header' });

    const token = header.split(' ')[1];
    const payload = verifyToken(token);
    if (!payload) return res.status(401).json({ error: 'Invalid or expired token' });

    (req as any).user = payload;
    next();
}
